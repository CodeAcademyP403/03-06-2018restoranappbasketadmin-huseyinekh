﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMD
{

    public class Command
    {
        public Command()
        {
            Name = "";
        }

        public string Name;
    }
}
